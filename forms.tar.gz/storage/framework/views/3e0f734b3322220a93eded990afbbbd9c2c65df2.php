<?php $__env->startSection('content'); ?>
<h2 class="page-header"><?php echo app('translator')->get('message.users'); ?></h2>

<div class="table-responsive">
  <table class="table table-hover">
    <thead>
      <tr>
        <th scope="col"><?php echo app('translator')->get('message.actions'); ?></th>
        <th scope="col"><?php echo app('translator')->get('message.avatar'); ?></th>
        <th scope="col"><?php echo app('translator')->get('message.name'); ?></th>
        <th scope="col"><?php echo app('translator')->get('message.email'); ?></th>
        <th scope="col"><?php echo app('translator')->get('message.role'); ?></th>
      </tr>
    </thead>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td>
          <a href="<?php echo e(route('admin.user.edit',    ['user'=>$user->id])); ?>" class="btn fa fa-pencil"></a>
          <a href="<?php echo e(route('admin.user.destroy', ['user'=>$user->id])); ?>" class="btn fa fa-trash-o delete"></a>
        </td>
        <td><img src="<?php echo e($user->avatar); ?>" style="width: 40px;"></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->role); ?></td>
      </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/forms/resources/views/admin/user/index.blade.php ENDPATH**/ ?>