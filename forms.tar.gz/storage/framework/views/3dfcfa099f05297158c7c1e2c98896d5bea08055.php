<?php $__env->startSection('content'); ?>
<h5>Dashboard</h5>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/forms/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>