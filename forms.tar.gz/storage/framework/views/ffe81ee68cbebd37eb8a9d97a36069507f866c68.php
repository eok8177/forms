<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>

  <!-- Styles -->
  <link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

  <div id="app">

    
    <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="fa fa-tachometer"></i> <span class="d-none d-md-inline"><?php echo app('translator')->get('message.dashboard'); ?></span>
        </a>

        <ul class="navbar-nav flex-row">
          <li class="nav-item">
            <a href="/" class="nav-link"><i class="fa fa-home"></i> <?php echo app('translator')->get('message.to_site'); ?></a>
          </li>

          <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?></a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <a href="<?php echo e(route('admin.user.edit', ['user' => Auth::user()->id])); ?>" class="dropdown-item"><i class="fa fa-gear"></i> <?php echo app('translator')->get('message.profile'); ?></a>

              <div class="dropdown-divider"></div>

              <h6 class="dropdown-header"><?php echo app('translator')->get('message.users'); ?></h6>

              <a class="dropdown-item" href="<?php echo e(route('admin.user.create')); ?>"><i class="fa fa-user"></i> <?php echo app('translator')->get('message.create'); ?></a>
              <a class="dropdown-item" href="<?php echo e(route('admin.user.index')); ?>"><i class="fa fa-users"></i> <?php echo app('translator')->get('message.users'); ?></a>

              <div class="dropdown-divider"></div>

              <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                 onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                  <i class="fa fa-sign-out"></i> <?php echo app('translator')->get('message.logout'); ?>
              </a>

              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
            </div>
          </li>

        </ul>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

      </div>

        
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <div class="navbar-nav flex-column side-nav">

            <a class="nav-item nav-link <?php echo e(request()->is('*user*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index')); ?>"><i class="fa fa-users"></i> <?php echo app('translator')->get('message.users'); ?></a>

          </div>
        </div>
    </nav>

    
    <div id="page-wrapper">
      <div class="container-fluid pt-md-3">

        <div class="flash-message">
          <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Session::has($msg)): ?>
              <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get($msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
        </div>

        <?php echo $__env->yieldContent('content'); ?>

      </div>
    </div>

    <a href="#app" class="btn btn-info d-none"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
  </div>

  

<!-- Scripts -->
<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/laravel-filemanager/js/lfm.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH /home/www/forms/resources/views/admin/layout.blade.php ENDPATH**/ ?>