<?php $__env->startSection('content'); ?>
<h2 class="page-header"><?php echo app('translator')->get('message.user'); ?> <small><?php echo e($user->name); ?></small></h2>

<?php echo Form::open(['route' => ['admin.user.update', $user->id], 'method' => 'PUT', 'class' => 'form-horizontal']); ?>

  <?php echo $__env->make('admin.user.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/forms/resources/views/admin/user/edit.blade.php ENDPATH**/ ?>