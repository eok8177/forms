@extends('admin.layout')

@section('content')
<h5>Dashboard</h5>


@endsection
