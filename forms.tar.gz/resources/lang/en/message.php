<?php

return [

    'action' => 'Action',
    'actions' => 'Actions',
    'create' => 'Create',
    'save' => 'Save',
    'chose' => 'Chose',
    'delete' => 'Delete',
    'select' => 'Select',
    'published' => 'Published',
    'gen_auto' => 'Generated auto',

    'dashboard' => 'Dashboard',
    'to_site' => 'Go to site',
    'settings' => 'Settings',
    'logout' => 'Logout',
    'category' => 'Category',
    'page' => 'Page',
    'preview' => 'Preview',
    'category' => 'Category',
    'categories' => 'Categories',
    'pages' => 'Pages',
    'page' => 'Page',
    'content' => 'Content',


    'new_user' => 'New user',
    'user' => 'User',
    'users' => 'Users',
    'username' => 'User name',
    'name' => 'Name',
    'avatar' => 'Avatar',
    'profile' => 'Profile',
    'new_password' => 'New password',
    'email' => 'Email',
    'role' => 'Role',
    'image' => 'Image',
    'slug' => 'Slug',
    'title' => 'Title',
    'description' => 'Description',
    'enabled' => 'Enabled',

];
